### Delivering a Better Experience by Using the Open, Collaborative and Flexible Grav CMS <br>– Inside or Outside of your LMS<br><br>
##### Paul D Hibbitts<br>[hibbittsdesign.org](https://hibbittsdesign.org/blog)<br>[@hibbittsdesign](https://twitter.com/hibbittsdesign)

---

### <i class="fa fa-rocket" aria-hidden="true"> </i> Topics to Explore Today <i class="fa fa-rocket" aria-hidden="true"> </i>
1. What is Grav?
2. Grav Open Course Hub Project
3. Other Open-related Grav Projects
4. Next Steps

---
<!-- .slide: data-background="#8fa33b" -->


### What is Grav?

---
<!-- .slide: data-background-image="./assets/md/assets/getgrav.png" data-background-size="contain" data-background-color="black" data-background-position="center" data-background-repeat=" " data-background-transition="none" -->


---
<!-- .slide: data-background-image="./assets/md/assets/getgrav-2.png" data-background-size="contain" data-background-color="black" data-background-position="center" data-background-repeat=" " data-background-transition="none" -->


---

### Grav Highlights

- File-based
    - Fast performance (esp. smaller sites), simplicity, portability and generally more secure
    - File-based content also naturally supports version control
    - Grav can also be a front-end for any collaborative Git repository
- Markdown
    - A platform-independent format perfect for writing and the 5Rs

---

### Grav Highlights

- Modular
    - Modular content is possible, along with custom content types
- Workflow
    - Supports an efficient edit and publish workflow (esp. Git-based)
- Customization
    - Powerful Blueprints supports Admin Panel customizations

---
<!-- .slide: data-background="#090909" -->


### Grav’s Layered Conceptual Design

![Image](./assets/md/assets/grav-conceptual-design.png)

---
<!-- .slide: data-background="#8fa33b" -->


### Open Course Hub Project

---

### Grav Open Course Hub
Built using Grav, Open Course Hub with Git Sync is designed to give tech-savvy educators an open, collaborative and flexible platform that they can partner with their current LMS

---

### Grav Open Course Hub

<ul class="squares">

<li class="fragment  " data-notes=" ">Streamlined setup and configuration (incl. Git Sync)</li>
<li class="fragment  " data-notes=" ">Supports open and collaborative content (via Git repository)</li>
<li class="fragment  " data-notes=" ">Theme files synced to Git repository for collaborative authoring/assistance</li>
<li class="fragment  " data-notes=" ">Example course hubs (incl. basic, intermediate. and advanced)</li>
<li class="fragment  " data-notes=" ">Includes custom content type pages and Shortcodes (i.e. Embed.ly Web page preview cards, H5P and Swipe)</li>
<li class="fragment  " data-notes=" ">Fully customizable Sidebar using Markdown or HTML</li>

</ul>

---
<!-- .slide: data-background-image="./assets/md/assets/grav-open-course-hub-skeleton-1.png" data-background-size="contain" data-background-color="#777777" data-background-position="center" data-background-repeat=" " data-background-transition="none" -->


---
<!-- .slide: data-background-image="./assets/md/assets/grav-open-course-hub-skeleton-2.png" data-background-size="contain" data-background-color="#000000" data-background-position="center" data-background-repeat=" " data-background-transition="none" -->


---
<!-- .slide: data-background-image="./assets/md/assets/grav-open-course-hub-skeleton-3.png" data-background-size="contain" data-background-color="#000000" data-background-position="center" data-background-repeat=" " data-background-transition="none" -->


---
<!-- .slide: data-background-image="./assets/md/assets/grav-open-course-hub-skeleton-4.png" data-background-size="contain" data-background-color="#777777" data-background-position="center" data-background-repeat=" " data-background-transition="none" -->


---
<!-- .slide: data-background-image="./assets/md/assets/grav-open-course-hub-skeleton-5.png" data-background-size="contain" data-background-color="#000000" data-background-position="center" data-background-repeat=" " data-background-transition="none" -->


---
<!-- .slide: data-background-image="./assets/md/assets/grav-open-course-hub-skeleton-6.png" data-background-size="contain" data-background-color="#000000" data-background-position="center" data-background-repeat=" " data-background-transition="none" -->


---
<!-- .slide: data-background-image="./assets/md/assets/grav-open-course-hub-skeleton-7.png" data-background-size="contain" data-background-color="#000000" data-background-position="center" data-background-repeat=" " data-background-transition="none" -->


---
<!-- .slide: data-background-image="./assets/md/assets/grav-open-course-hub-skeleton-8.png" data-background-size="contain" data-background-color="#000000" data-background-position="center" data-background-repeat=" " data-background-transition="none" -->


---
<!-- .slide: data-background-image="./assets/md/assets/grav-open-course-hub-skeleton-9.png" data-background-size="contain" data-background-color="#777777" data-background-position="center" data-background-repeat=" " data-background-transition="none" -->


---
<!-- .slide: data-background-image="./assets/md/assets/grav-open-course-hub-skeleton-10.png" data-background-size="contain" data-background-color="#000000" data-background-position="center" data-background-repeat=" " data-background-transition="none" -->


---
<!-- .slide: data-background-image="./assets/md/assets/grav-open-course-hub-skeleton-11.png" data-background-size="contain" data-background-color="#000000" data-background-position="center" data-background-repeat=" " data-background-transition="none" -->


---
<!-- .slide: data-background-image="./assets/md/assets/github-clone.png" data-background-size="contain" data-background-color="#000000" data-background-position="center" data-background-repeat=" " data-background-transition="none" -->


---
<!-- .slide: data-background-image="./assets/md/assets/atom-editor.png" data-background-size="contain" data-background-color="#000000" data-background-position="center" data-background-repeat=" " data-background-transition="none" -->


---

### <i class="fa fa-laptop" aria-hidden="true"> </i> What Skills are Required? <i class="fa fa-laptop" aria-hidden="true"> </i>

<ul class="squares">

<li class="fragment  " data-notes=" ">Intended for “Tech-savvy” educators:</li>
<li class="fragment li-nested-item" data-notes=" ">Code editor usage (e.g. Atom or Brackets)</li>
<li class="fragment li-nested-item" data-notes=" ">Markdown or HTML basics</li>
<li class="fragment li-nested-item" data-notes=" ">Understanding folder hierarchies (i.e. relative links)</li>
<li class="fragment li-nested-item" data-notes=" ">Web server access</li>
<li class="fragment li-nested-item" data-notes=" ">GitHub working knowledge (recommended)</li>

</ul>

---

### Grav Open Course Hub is Intended for Tech-savvy Educators who Value:

- Controllability
- Flexibility
- Portability
- Efficiency
- Openness
- Participation

---
<!-- .slide: data-background-image="./assets/md/assets/grav-open-course-workflow-1.png" data-background-size="contain" data-background-color="white" data-background-position="center" data-background-repeat=" " data-background-transition="none" -->


---
<!-- .slide: data-background-image="./assets/md/assets/grav-open-course-workflow-2.png" data-background-size="contain" data-background-color="white" data-background-position="center" data-background-repeat=" " data-background-transition="none" -->


---
<!-- .slide: data-background-image="./assets/md/assets/grav-open-course-workflow-3.png" data-background-size="contain" data-background-color="white" data-background-position="center" data-background-repeat=" " data-background-transition="none" -->


---
<!-- .slide: data-background-image="./assets/md/assets/grav-open-course-workflow-4.png" data-background-size="contain" data-background-color="white" data-background-position="center" data-background-repeat=" " data-background-transition="none" -->


---

### Problems the Course Hub Tackles

- Pedagogical goals that are unmet by the current LMS
- Student and facilitator experiences, especially multi-device, are below expectations
- Ability to access, share and collaboratively edit course materials is lacking
- The creation and updating of online materials is too time consuming
- Online course materials are difficult to repurpose
- Unable to leverage existing Web authoring skills or standards on the current Learning Platform

---

### <i class="fa fa-comment" aria-hidden="true"> </i> Want a User Quote? <i class="fa fa-comment" aria-hidden="true"> </i>

---

> “The Open Course Hub was easy to set up and get running and my students loved having a one-stop place to go to for their course content. I really love that it syncs with GitHub so easily and seamlessly. I was able to have an open, collaborative, easily updatable, fully version-controlled site up and running in little time, with fairly modest technical skills. On the student side, it is all beautiful and easy to use on any device!”<br>
— Mark Coster (Associate Professor at Griffith University, Australia)

---

### Enough Talk, Demo Time!  

#### [demo.hibbittsdesign.org/cmpt-363-173/](http://demo.hibbittsdesign.org/cmpt-363-173/)

---

### How about _Inside_ of<br> an LMS?
#### [canvas.sfu.ca/courses/38847](https://canvas.sfu.ca/courses/38847)

---

### <i class="fa fa-comment" aria-hidden="true"> </i> Time for a Student Quote! <i class="fa fa-comment" aria-hidden="true"> </i>

---

> “The 363 Canvas course website does an excellent job of presenting only the current week’s relevant assignments and readings on the Home page. This makes using the site a breeze because no time is required to actually navigate the site – all the important stuff is there in one click!”<br>
— SFU CMPT-363 Student, Using Canvas LMS partnered with Open Course Hub

---
<!-- .slide: data-background="#8fa33b" -->


### How About Other Open-related Grav Projects?

---

### More Open-related Grav Projects

- Open Publishing Space
    - Share and collaboratively edit Markdown-based OER
- Learn2 with Git Sync
    - Share and collaboratively edit Markdown-based documentation
- H5P Shortcode
    - Display H5P.org and locally store H5P content
- Hypothesis Plugin
    - Display the Hypothesis sidebar on your Grav site

---
<!-- .slide: data-background="#FFFFFF" -->


### <span style="color: black">Open Publishing Space</span>

![Image](./assets/md/assets/grav-open-publishing-space.png)

---
<!-- .slide: data-background="#FFFFFF" -->


### <span style="color: black">Learn2 with Git Sync</span>

![Image](./assets/md/assets/grav-learn2-with-git-sync.png)

---
<!-- .slide: data-background="#FFFFFF" -->


### <span style="color: black">H5P Shortcode</span>

```
[h5p id="712"]
[h5p url="https://h5p.org/h5p/embed/712"]
```

![Image](./assets/md/assets/h5p.png)

---
<!-- .slide: data-background="#FFFFFF" -->


### <span style="color: black">Hypothesis Plugin</span>

![Image](./assets/md/assets/grav-hypothesis-plugin.png)

---
<!-- .slide: data-background="#8fa33b" -->


### Next Steps

---

### Things to Explore Next

Grav CMS Official Site  
[getgrav.org](https://getgrav.org)  

Markdown  
[Learn the basics of Markdown in ten minutes](https://designedbywaldo.com/en/tools/markdown-tutorial)  

GitHub Workflow  
[Introduction - Git and GitHub for Poets](https://www.youtube.com/watch?v=BCQHnlnPusY&index=1&list=PLRqwX-V7Uu6ZF9C0YMKuns9sLDzK6zoiV)  
[GitHub Desktop App](https://desktop.github.com/)  

---

### <i class="fa fa-exclamation-triangle" aria-hidden="true"> </i> Pop Quiz <i class="fa fa-exclamation-triangle" aria-hidden="true"> </i>
Which of these “tech-savvy” skills are the biggest challenge?
 - Text editor usage (e.g. Atom or Brackets)
 - Markdown or HTML basics
 - Understanding folder hierarchies (i.e. relative links)
 - Web server access
 - GitHub or GitLab working knowledge
 - GitHub Desktop App (not needed if using Atom)
 - ...or something else that you’ve seen today?

---

### <i class="fa fa-star" aria-hidden="true"> </i> Thank you. Q&A Time! <i class="fa fa-star" aria-hidden="true"> </i>

**Contact Info**  
Blog: [hibbittsdesign.org](http://hibbittsdesign.org/blog)  
Twitter: [@hibbittsdesign](https://twitter.com/hibbittsdesign)  
Email: [paul@hibbittsdesign.org](mailto://paul@hibbittsdesign.org)  

**Grav Open Course Hub**  
Docs: [learn.hibbittsdesign.org/coursehub](http://learn.hibbittsdesign.org/coursehub)  
Canvas Demo: [demo.hibbittsdesign.org/canvascoursehub](http://demo.hibbittsdesign.org/canvascoursehub)  
Moodle Demo: [demo.hibbittsdesign.org/moodlecoursehub](http://demo.hibbittsdesign.org/moodlecoursehub)  